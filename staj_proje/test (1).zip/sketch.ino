#include <WiFi.h>

const int BTN_GIRIS   = 14; 
const int BTN_CIKIS   = 12; 

const int LED_GREEN   = 23;
const int LED_YELLOW  = 22; 
const int LED_RED     = 18; 

const char* ssid = "Wokwi-GUEST";
const char* password = "";

int lastStateGiris = HIGH;
int lastStateCikis = HIGH;

void setup() {
  Serial.begin(115200);


  pinMode(BTN_GIRIS, INPUT_PULLUP);
  pinMode(BTN_CIKIS, INPUT_PULLUP);

  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_YELLOW, OUTPUT);
  pinMode(LED_RED, OUTPUT);

  Serial.println("\n[SİSTEM] ESP32 Başlatılıyor...");
  digitalWrite(LED_YELLOW, HIGH);
  delay(500);

  Serial.print("[AĞ] Wi-Fi Bağlantısı Kuruluyor");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
    digitalWrite(LED_YELLOW, !digitalRead(LED_YELLOW));
  }

  digitalWrite(LED_YELLOW, HIGH);
  Serial.println("\n[AĞ] Wi-Fi Bağlantısı Başarılı!");
  Serial.print("[AĞ] IP Adresi: ");
  Serial.println(WiFi.localIP());
  Serial.println("[SİSTEM] PDKS Buton Simülasyonu Hazır.\n");
}

void loop() {
  int currentStateGiris = digitalRead(BTN_GIRIS);
  int currentStateCikis = digitalRead(BTN_CIKIS);

  if (lastStateGiris == HIGH && currentStateGiris == LOW) {
    Serial.println("[LOJİK SİNYAL] Giriş Butonuna Basıldı (GPIO 14 -> LOW)");
    Serial.println("[EYLEM] Personel GİRİŞ Kaydı Oluşturuluyor...");

    digitalWrite(LED_GREEN, HIGH);
    delay(1000);
    digitalWrite(LED_GREEN, LOW);
    Serial.println("[SONUÇ] Giriş Kaydı Başarıyla İşlendi.\n");
  }

  if (lastStateCikis == HIGH && currentStateCikis == LOW) {
    Serial.println("[LOJİK SİNYAL] Çıkış Butonuna Basıldı (GPIO 12 -> LOW)");
    Serial.println("[EYLEM] Personel ÇIKIŞ Kaydı Oluşturuluyor...");

    digitalWrite(LED_GREEN, HIGH);
    delay(1000);
    digitalWrite(LED_GREEN, LOW);
    Serial.println("[SONUÇ] Çıkış Kaydı Başarıyla İşlendi.\n");
  }

  lastStateGiris = currentStateGiris;
  lastStateCikis = currentStateCikis;
  delay(50);
}